package ����̨ʵ��������Socket_hard;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * �ͻ���
 * 127.0.0.1:���͵�ַ,ָ����
 * @author Rowin
 * 2017-3-30
 *
 */
public class Client {
	public static void main(String[] args) {
		System.out.println("�ͻ�������");
		try {
			Socket s=new Socket("127.0.0.1",1996);
			new SendThread(s).start();
			new GetThread(s).start();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
//������Ϣ���߳�
class SendThread extends Thread{
	private Socket s;
	public SendThread(Socket s){
		this.s=s;
	}
	public void run(){
		try {
			OutputStreamWriter osw=new OutputStreamWriter(s.getOutputStream());
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			while (true) {
				String content=br.readLine();
				osw.write(content+"\n");
				osw.flush();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
//������Ϣ���߳�
class GetThread extends Thread{
	private Socket s;
	public GetThread(Socket s){
		this.s=s;
	}
	public void run(){
		try {
			while(true){
				InputStreamReader isr=new InputStreamReader(s.getInputStream());
				BufferedReader br=new BufferedReader(isr);
				String content=br.readLine();
				System.out.println(content);
				
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
