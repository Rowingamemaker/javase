package ͼ�ν���������;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * �ͻ���
 * ���ܷ���˷��͹�������Ϣ
 * ������˷�����Ϣ
 * @author Rowin
 * 2017-3-30
 *
 */
public class Client extends JFrame{
	private Socket s;
    JPanel jp1,jp2;
    JTextField jtf;///�����ı���
    JTextArea jta;///�����ı���
    JScrollPane jsp;
	public static void main(String[] args) {
//		new Client();
	}
	public Client(Socket s) {
		// TODO Auto-generated constructor stub
    	this.s=s;
		jp1=new JPanel();
		jta=new JTextArea(20,30);
		jsp=new JScrollPane(jta);//ʹjta���й���������
		jp1.add(jsp);
		
		
		jp2=new JPanel();
		jtf=new JTextField(30);
		jp2.add(jtf);
		this.add(jp1);
		this.add(jp2);
		this.setLayout(new BorderLayout());
		this.add(BorderLayout.CENTER,jp1);
		this.add(BorderLayout.SOUTH,jp2);
		this.pack();
		this.setVisible(true);
		jtf.addActionListener(new MyListener());
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		jtf.addActionListener(new MyListener());
		new GetThread().start();
	}
	class MyListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
//			jta.setText(jta.getText()+"\n"+jtf.getText());
//			jtf.setText("");
			///�������������Ϣ
			String content=jtf.getText();
			try {
				OutputStreamWriter osw=new OutputStreamWriter(s.getOutputStream());
				osw.write(content+"\n");
				osw.flush();
				jtf.setText("");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}			
		}		
	}
	///���ܷ�������������Ϣ
	class GetThread extends Thread{
		public void run(){
			try {
				BufferedReader	br = new BufferedReader(new InputStreamReader(s.getInputStream()));
				while (true) {
					String content=br.readLine();
					jta.setText(jta.getText()+ "\n"+content);					
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
