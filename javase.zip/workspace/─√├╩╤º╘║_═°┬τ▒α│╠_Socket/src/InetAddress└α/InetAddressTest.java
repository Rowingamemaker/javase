package InetAddress��;

import java.net.Inet4Address;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddressTest {
	public static void main(String[] args) {
		InetAddress baidu = null;
		try {
			///��getByName��ȡIp��ַ
			baidu = InetAddress.getByName("www.baidu.com");
			System.out.println(baidu);
			System.out.println("---------------------");
			
			///��InetAddress��ȡIp��ַ
			InetAddress[]baidu1 =InetAddress.getAllByName("www.baidu.com");
			for (InetAddress inetAddress : baidu1) {
				System.out.println(inetAddress);
			}
			InetAddress my=InetAddress.getLocalHost();
			System.out.println("����: "+my);
			//100.132.66.21
			byte[]bs=new byte[]{100,(byte)132,66,21};
			InetAddress is=InetAddress.getByAddress(bs);
			System.out.println();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
