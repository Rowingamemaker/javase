package URL��;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * URL:ͳһ��Դ��λ��,����ʾInternet��ĳһ��Դ�ĵ�ַ
 * @author Rowin
 * 2017-3-29
 *
 */
public class URLTest {
	public static void main(String[] args) {
		try {
			URL url=new URL("https://ke" +
					".qq.com/?from=7&time=" +
					"1490657486704&ADUI" +
					"N=379657948&ADSESSION=1" +
					"490657480&ADTAG=CLIENT" +
					".QQ.5515_.0&ADPUBNO=26657");
			System.out.println("����: "+url.getHost());
			System.out.println("�˿�: "+url.getPort());
			System.out.println("·��: "+url.getPath());
			System.out.println("Э��: "+url.getProtocol());
			System.out.println("�ļ���:"+url.getFile());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
