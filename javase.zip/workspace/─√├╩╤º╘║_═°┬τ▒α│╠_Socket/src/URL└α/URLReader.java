package URL��;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
/**
 * 
 * @author Rowin
 * 2017-3-29
 *
 */
public class URLReader {
	public static void main(String[] args) {
		try {
			URL url=new URL("http://www.xmcu.cn/");
			InputStreamReader isr=new InputStreamReader(url.openStream()); 
			BufferedReader br=new BufferedReader(isr);
			String line=null;
			while ((line=br.readLine())!=null) {
				System.out.println(line);
			}
			isr.close();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
