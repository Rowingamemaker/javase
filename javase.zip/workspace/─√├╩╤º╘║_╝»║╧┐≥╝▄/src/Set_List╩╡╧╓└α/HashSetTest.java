package Set_Listʵ����;
/**
 * hashset������˳���ǰ�����add��˳��,�ǰ��չ�ϣ��
 */
import java.util.HashSet;

public class HashSetTest {
	public static void main(String[] args) {
		HashSet<String>hash=new HashSet<String>();
		hash.add("a");
		hash.add("b");
		hash.add("c");
		hash.add("d");
		System.out.println(hash);
		
		String[]s=new String[hash.size()];
		
		hash.toArray(s);
		for (String string : s) {
			System.out.print(string);
		}
		System.out.println();
		
		HashSet<String>hash1=new HashSet<String>(hash);	
		System.out.println(hash1);
		HashSet<String>hash2=new HashSet<String>();
		hash2.addAll(hash);
		System.out.println(hash2);
		
		
	}

}
