package Rowin;

import java.util.List;

/**
 * ������
 * @author Rowin
 * 2017-3-18
 *
 */
public class Consumer extends Thread{
	private List<Integer>list;
	private int max;
	public Consumer(String name,int max,List<Integer> list) {
		super(name);
		this.list = list;
		this.max = max;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			synchronized (list) {
				while (list.isEmpty()) {
					System.out.println("�ֿ����");
					try {
						list.wait();
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println(this.getName()+"��������"+list.get(list.size()-1));
				list.remove(list.size()-1);
				list.notifyAll();
			}
		}
	}
	

}
