package Rowin;

import java.util.ArrayList;
import java.util.List;

public class Test {
	public static void main(String[] args) {
		List<Integer>list=new ArrayList<Integer>();
		int max=100;
		
		Producer p=new Producer("������", max, list);
		Consumer C=new Consumer("������", max, list);
		
		p.start();
		C.start();

	}
}
