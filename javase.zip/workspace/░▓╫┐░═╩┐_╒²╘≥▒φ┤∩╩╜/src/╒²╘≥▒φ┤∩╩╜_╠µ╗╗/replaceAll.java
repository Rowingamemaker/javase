package �������ʽ_�滻;

public class replaceAll {
	public static void main(String[] args) {
		function_Demo1();
		function_Demo2();
		function_Demo3();
	}

	//��t��m����#
	public static void function_Demo1() {
		String str = "RowintttBoBommmmmmmmmmNice";
		
		str=str.replaceAll("(.)\\1+", "#");
		System.out.println(str);
	}
	//��t��m����һ��t��һ��m
	public static void function_Demo2() {
		String str = "RowintttBoBommmmmmmmmmNice";
		
		str=str.replaceAll("(.)\\1+", "$1");
		System.out.println(str);
	}
	//��15800001111����158****1111
	public static void function_Demo3() {
		String tel="158000011111";
//		tel=tel.replaceAll("0+", "****");
		tel=tel.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
		System.out.println(tel);
	}
}
