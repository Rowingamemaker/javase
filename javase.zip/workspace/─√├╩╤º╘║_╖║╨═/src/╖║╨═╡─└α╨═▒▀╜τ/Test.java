package ���͵����ͱ߽�;

public class Test {
	public static void main(String[] args) {
		Integer []is={1,2,3,4,5};
		Average<Integer>a=new Average<Integer>(is);
		System.out.println(a.average());
		
		Double[]ds={1.0,2.0,3.0,4.0,9.0};
		Average<Double> d=new Average<Double>(ds);
		System.out.println(a.equalaAve(d));
	}
}
