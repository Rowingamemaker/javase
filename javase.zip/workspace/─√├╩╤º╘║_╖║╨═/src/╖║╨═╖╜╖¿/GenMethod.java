package ���ͷ���;
/**
 * 
 * @author Rowin
 * 2017-3-21
 *
 */
public class GenMethod {
	
	////���ͷ���  
	public static <T>boolean have(T[]ts,T t){
		 boolean have=false;
		 for (int i = 0; i < ts.length; i++) {
			 if (t.equals(ts[i])) {
				have=true;
				break;
			}
		}
			return have;
	}
	public static void main(String[] args) {
		Integer[] ts={1,2,3,4,5,6};
		boolean have=have(ts, 5);
		if (have) {
			System.out.println("����");
		}else {
			System.out.println("������");
		}
	}

}
