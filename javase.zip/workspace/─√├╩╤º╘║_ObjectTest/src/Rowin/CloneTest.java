package Rowin;

public class CloneTest{
	/////�����׳��쳣
	public static void main(String[] args) throws CloneNotSupportedException {
		Student s1=new Student();
		s1.setName("����");
		s1.setAge(10);
		s1.setSex("��");
		System.out.println(s1);
		
		Student s2=s1.clone();
		System.out.println(s2);
		///�ж��Ƿ�Ϊ����
		System.out.println(s1==s2);

	}

}
////ִ��clone����Ҫʵ��Cloneable
class Student implements Cloneable{
	private String name;
	private String sex;
	private int age;	
	///��дclone
	public Student clone() throws CloneNotSupportedException{
		////��Ϊsuper.clone()���ص���Object����,����ҪǿתΪStudent����
		return (Student)super.clone();
	}
	
	
	
	
	public String toString() {
		return "Student [name=" + name + ", sex=" + sex + ", age=" + age + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}

