
public class String {

}
