package test1_1;

public class HelloWorld {
	
	public static void main(String []args){
		final int APPLE_PRICE_PER_KM;
		int weightOfApple;
		int money;
		APPLE_PRICE_PER_KM=3;
		weightOfApple=5;
		money=APPLE_PRICE_PER_KM*weightOfApple;
		System.out.println("��ƻ������"+money+"Ա");		
	}
}
