package Rowin;
import java.util.Iterator;
/**
 * ����1~100����Ȼ���е�ż��֮��   do...while...
 * @author Rowin
 * 2017-3-8
 *
 */
public class test3 {
	public static void main(String[] args) {
		DoWhileCountNumber();
		WhileCountNumber();
		ForCountNumber();
	}
	////1.Do while���ʵ��
	static void DoWhileCountNumber(){
		int i=1;
		int total=0;
		do {
			if (i%2==0) {
				total+=i;
			}
			i++;
			
		} while (i<=100);
		System.out.println("Do...while  total = "+total);
	}
	////2.while���ʵ��
	static void WhileCountNumber(){
		int i=1;
		int total=0;
		while (i<=100) {
			if (i%2==0) {
				total+=i;
			}
			i++;
		}
		System.out.println("while       total = "+total);
	}
	////3.for���ʵ��`
	static void ForCountNumber(){
		int total=0;
		for(int i=1;i<=100;i++){
			if (i%2==0) {
				total+=i;
			}
		}
		System.out.println("For         total = "+total);
	}
}
