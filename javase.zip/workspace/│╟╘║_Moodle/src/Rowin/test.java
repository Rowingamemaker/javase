package Rowin;

public class test {
	public static void main(String[] args) {
		int i = 1;
		int total = 0;
		do {
			if (i % 2 == 0) {
				total += i;
			}
			i++;

		} while (i <= 100);
		System.out.println("result = " + total);
	}
}
