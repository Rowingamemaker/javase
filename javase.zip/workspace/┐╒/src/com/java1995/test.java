package com.java1995;

public class test {
	public static void main(String[] args) {
		People p=new Student();
		p.peopleshow();
		Student s=(Student)p;
		s.studentshow();
	}
}

class People {
	int a;

	void peopleshow() {
		System.out.println("people");
	}
}

class Student extends People {
	int b;
	void studentshow(){
		System.out.println("student");
	}

}
class Teather extends People{
	int c;
	void teathershow(){
		System.out.println("teather");
	}
}