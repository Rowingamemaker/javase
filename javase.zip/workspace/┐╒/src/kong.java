class A {
	public int change(){
		return 4;
	}
	
}
class Child extends A{
	
	public int change(){
		return 5;
	}
}
public class kong{
	public static void main(String[] args) {
		A a=new A();
		Child c=new Child();
		System.out.println(a.change()+". "+c.change());
	}
}
