package �߳�_�̳�Thread;

public class main {
	public static void main(String[] args) {
		MyThread mt1=new MyThread("�߳�1");
		mt1.start();
		MyThread mt2=new MyThread("�߳�2");
	
		mt2.start();
		for (int i = 0; i < 10; i++) {
			try {
				mt1.sleep(100);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			System.out.println("���߳�"+i);

			
		}	
		
		System.out.println("MAIN");
	}
	
	
}
