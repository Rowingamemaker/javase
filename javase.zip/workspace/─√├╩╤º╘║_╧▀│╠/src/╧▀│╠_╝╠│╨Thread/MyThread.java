package �߳�_�̳�Thread;

public class MyThread extends Thread{
	public MyThread(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	public void run(){
		for (int i = 0; i <10; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("MyThread "+i);
		}
	}

}
