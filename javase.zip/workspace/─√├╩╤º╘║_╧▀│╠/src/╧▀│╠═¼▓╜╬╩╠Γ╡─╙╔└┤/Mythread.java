package �߳�ͬ�����������;

public class Mythread extends Thread{
	Source s;
	String name;
	Mythread(String name,Source s){
		this.name=name;
		this.s=s;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		if ("method1".equals(name)) {
			s.method1();
		}else {
			s.method2();
		}
	};
	public static void main(String[] args) {
		Source s=new Source();
		Mythread m1=new Mythread("method1", s);
		Mythread m2=new Mythread("method2", s);
		
		m1.start();
		m2.start();

	}
}
