package �߳�ͬ�����������;

public class teacher implements Runnable{
	private print p;
	private String name;
	private int escore, mscore, cscore;
	public teacher(print p,String name,int escore,int mscore, int cscore) {
		// TODO Auto-generated constructor stub
		this.p=p;
		this.name=name;
		this.escore=escore;
		this.mscore=mscore;
		this.cscore=cscore;
		
	}
	public print getP() {
		return p;
	}
	public void setP(print p) {
		this.p = p;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEscore() {
		return escore;
	}
	public void setEscore(int escore) {
		this.escore = escore;
	}
	public int getMscore() {
		return mscore;
	}
	public void setMscore(int mscore) {
		this.mscore = mscore;
	}
	public int getCscore() {
		return cscore;
	}
	public void setCscore(int cscore) {
		this.cscore = cscore;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		p.printScore(name, escore, mscore, cscore);
	}
	
}
