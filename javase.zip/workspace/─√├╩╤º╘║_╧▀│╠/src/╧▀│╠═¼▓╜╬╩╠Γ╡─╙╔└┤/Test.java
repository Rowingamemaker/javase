package �߳�ͬ�����������;

public class Test {
	public static void main(String[] args) {
		print p=new print();
		teacher t1=new teacher(p,"boob1", 10, 11, 12);
		teacher t2=new teacher(p,"boob2", 13, 14, 15);
		teacher t3=new teacher(p,"boob3", 16, 17, 18);
		Thread th1=new Thread(t1);
		Thread th2=new Thread(t2);
		Thread th3=new Thread(t3);
		th1.start();
		th2.start();
		th3.start();
	}

}
