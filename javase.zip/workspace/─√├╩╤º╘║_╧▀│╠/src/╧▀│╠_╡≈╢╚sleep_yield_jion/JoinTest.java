package �߳�_����sleep_yield_jion;

public class JoinTest {
	public static void main(String[] args) {
		MyThread t1=new MyThread();
		t1.start();
		for (int i = 0; i < 10; i++) {
			if (i==5) {
				try {
		///////////////////////////��i=5��ʱ��,t1����̼߳������,
					t1.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			System.out.println("+");
		}
	}

}
class MyThread extends Thread{
	public void run(){
		for (int i = 0; i < 10; i++) {
			System.out.println("*");
		}
	}
}
