package �߳�_����sleep_yield_jion;

import java.util.Date;

/**
 *1. sleep    2.new Date()  ����ϵͳʱ��  
 * @author Rowin
 * 2017-3-9
 *
 */
public class SleepTest {
	public static void main(String[] args) {
//		for (int i = 0; i < 10; i++) {
//			System.out.println(i);
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
		///////////////new Date()
		while (true) {
			System.out.println(new Date());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}
}
