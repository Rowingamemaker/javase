package �߳�_ʵ��Runnable�ӿ�;

public class test {
	public static void main(String[] args) {
		////������Runnableʵ��
		MyThread mt=new MyThread();
		Thread t=new Thread(mt);
		t.start();
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("���߳�"+i);
	}
	}
}
