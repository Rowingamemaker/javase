package �������л�;
/**
 * ���л��ͷ����л�
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class SerializebleTest {
	public static void main(String[] args) {
		FileOutputStream fos=null;
		FileInputStream fis=null;
		
		ObjectOutputStream oos=null;
		ObjectInputStream  ois=null;
		
		try {
			fos=new FileOutputStream("C:\\Users\\Rowin\\Desktop\\out.txt");
			oos=new ObjectOutputStream(fos);
			///д��Object����     ���л�
			Student s1=new Student();
			Student s2=new Student();

			s1.setName("Rowin");
			s1.setId(160249021);
			s1.setSex("��");
			s1.setAddr("�й�����");
			
			s2.setName("����");
			s2.setId(379657);
			s2.setSex("nan");
			s2.setAddr("����s");
			
			oos.writeObject(s1);
			oos.writeObject(s2);
			System.out.println("д����ɹ�");
			//��Object����  �����л�
			fis=new FileInputStream("C:\\Users\\Rowin\\Desktop\\out.txt");
			ois=new ObjectInputStream(fis);
			////Ҫ����ǿת  ��ΪreadObject�ķ���ֵ��Object
			Student r_s1=(Student)ois.readObject();
			Student r_s2=(Student)ois.readObject();
			
			System.out.println(r_s1);
			System.out.println(r_s2);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fos.close();
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
