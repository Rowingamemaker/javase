package �������л�;
/**
 * ֻ�м̳���Serializeble����������л�
 * ��transient���ε��ֶ��ǲ��ᱻ���л���
 */
import java.io.Serializable;


public class Student implements Serializable{
	private String name;
	private String sex;
	private String addr;
	private transient int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", sex=" + sex + ", addr=" + addr
				+ ", id=" + id + "]";
	}
	

}
