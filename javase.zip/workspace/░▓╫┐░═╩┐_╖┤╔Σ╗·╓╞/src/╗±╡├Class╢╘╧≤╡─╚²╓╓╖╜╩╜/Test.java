package ���Class��������ַ�ʽ;

public class Test {
	public String testString;
	private int test;
	public Test(String testString, int test) {
		super();
		this.testString = testString;
		this.test = test;
		System.out.println("�вεĹ��캯��");
	}
	public Test() {
		super();
		System.out.println("�޲εĹ��캯��");
		// TODO Auto-generated constructor stub
	}
	private void show(){
		System.out.println("show method runing");
	}
	public void name() {
		System.out.println("name method runing");
		
	}
	public void name(String name,int age){
		System.out.println(name+":"+age);
	}
}
