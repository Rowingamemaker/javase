package ReflectTest;

public interface PCI {

	public  void  open();
	public void close();
}
