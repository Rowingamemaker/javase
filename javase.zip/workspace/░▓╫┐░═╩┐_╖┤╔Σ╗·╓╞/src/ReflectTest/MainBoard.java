package ReflectTest;

public class MainBoard {
	public void run(){
		System.out.println("main board run ");
	}
	public void userPCI(PCI p){
		if (p!=null) {
			p.open();
			p.close();			
		}
	}
}
