package com.java1995;

public class kong {
	
}
