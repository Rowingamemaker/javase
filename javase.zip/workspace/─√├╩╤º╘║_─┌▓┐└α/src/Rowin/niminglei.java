package Rowin;

public class niminglei {
	private  int a=5;
	public Object makeInner(int localVar){
		final int InnerlocalVar=localVar;
		return new Object(){
			public String  tostring() {
				return "Outsize = "+a+"\nInnerlocalVar = "+InnerlocalVar;
			}
		};
	}
	public static void main(String[] args) {
		Object obj=new niminglei().makeInner(47);
		System.out.println(obj.toString());
	}

}
