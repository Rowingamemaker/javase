package Rowin;

public class staticlei {
	static private int x1=100;
	static private String str1="Rowin";
	static class staticInner{
		private int x1=1;
		private String str1="Hello World";
		public void  staticMethod() {
			System.out.println("�ⲿ���x1"+staticlei.x1);
			System.out.println("�ⲿ���str1"+staticlei.str1);
			
		}
//		public static void main(String[] args) {
//			staticlei.staticInner staticin=new staticInner();
//			staticin.staticMethod();
//		}
		
	}

}
