package Rowin;

 class mian {
	static private int size = 5, y = 7;

	 public Object makeInner(int localVar) {
		final int finalLocalVar = localVar;

		class MyInner {
			int y = 4;

			public String toString() {
			return "OutSize :"+size+"\nfinalLocalVar"+"this.y"+this.y;
			}
		}
		return new MyInner();

	}

}
public class jubulei{
	public static void main(String []args) {
		// TODO Auto-generated constructor stub
		Object obj=new mian().makeInner(47);
		System.out.println(obj.toString());
	}
}
