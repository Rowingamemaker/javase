package Rowin;

public class test {
	public static void main(String[]args) {
		// TODO Auto-generated method stub
		Me e=new Me();
		e.eat();
		e.play();
		e.sleep();
		System.out.println(Me.banji);

	} 

}
