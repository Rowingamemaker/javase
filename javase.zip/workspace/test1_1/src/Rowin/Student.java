package Rowin;

public interface Student {
	void eat();
	void play();
	void sleep();
	int banji=100;
}
