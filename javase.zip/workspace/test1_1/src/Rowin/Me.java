package Rowin;

public class Me implements Student {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("ѧ���ڳԷ�");
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		System.out.println("ѧ������lol");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("��������,ȥ˯��");
	}

	/**
	 * @param args
	 */

}
