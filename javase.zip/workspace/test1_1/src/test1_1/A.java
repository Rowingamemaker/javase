package test1_1;

public class A {
	void fun(){
		System.out.println("�ⲿ��");
	}
	public class inA{
		void fun(){
			System.out.println("�ڲ���");
		}
	}
}
