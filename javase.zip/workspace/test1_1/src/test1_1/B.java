package test1_1;

public class B {
	public static void main(String[] args) {
		Outer ou=new Outer();
		inter oi=ou.eat(1);
		oi.show();
		
	}
	
}
class Outer{
	private String name;

	int flag;
	public inter eat(final int i){
		final int count=0;
		class inner implements inter{
			public void show(){////�ӿ�����Ĭ����public  ���Լ̳е�ʱ��ҲҪ����Ϊpublic
				System.out.println("shduag");
				}
			}
		return new inner();
	}
}
interface inter{
	void show();
}