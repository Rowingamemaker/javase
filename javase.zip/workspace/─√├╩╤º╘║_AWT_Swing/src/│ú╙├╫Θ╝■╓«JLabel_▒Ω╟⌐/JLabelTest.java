package �������֮JLabel_��ǩ;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JLabelTest {
	public static void main(String[] args) {
		new MyFrame();
	}
}
class MyFrame extends JFrame{
	public MyFrame(){
		this.setTitle("����JLabel");
		this.setSize(500,300);
		
		Icon image=new ImageIcon("C:\\Users\\Rowin\\Desktop\\����.PNG");
		JLabel label=new JLabel(image);
		this.add(label);
		this.setVisible(true);
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);	
			}
			});
	}
}
