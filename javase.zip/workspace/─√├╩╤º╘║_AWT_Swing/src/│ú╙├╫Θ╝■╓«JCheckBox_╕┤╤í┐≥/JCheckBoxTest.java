package �������֮JCheckBox_��ѡ��;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JCheckBoxTest extends JFrame implements ItemListener{
	public static void main(String[] args) {
		 new JCheckBoxTest();
	}
	JPanel jp=new JPanel();
	//������ѡ��
	JCheckBox jcb1=new JCheckBox("java");
	JCheckBox jcb2=new JCheckBox("php");
	JCheckBox jcb3=new JCheckBox("c++");
	JLabel jl=new JLabel();
	
	public JCheckBoxTest() {
		// TODO Auto-generated constructor stub
		///�����¼�������
		jcb1.addItemListener(this);
		jcb2.addItemListener(this);
		jcb3.addItemListener(this);
		
		
		this.add(jp);
		this.setTitle("JCheckBox��ʹ��");
		jp.add(new JLabel("ѡ������"));
		jp.add(jcb1);
		jp.add(jcb2);
		jp.add(jcb3);
		jp.add(jl);
		this.setSize(400,400);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
	//////�¼�������/////////////////////////////////////
	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		JCheckBox cb=(JCheckBox)e.getItem();
		if (e.getStateChange()==ItemEvent.SELECTED) {
			jl.setText(jl.getText()+cb.getText()+" ");		
		}
		
	}

}
