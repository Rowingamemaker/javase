package AWTDemo;

import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class AwtTest extends Frame {
	String keystr="";//��¼�����¼�
	String mousestr="";//��¼����¼�
	int mouseX=0;//x����	
	int mouseY=0;//Y����
	public AwtTest(){
		this.addKeyListener(new MyKeyAdapter(this));
		this.addMouseListener(new MyMouseAdapter(this));
		this.addWindowListener(new MyWindowAdapter());
	}
	public void paint(Graphics g) {
		g.drawString(keystr, 10, 50);
		g.drawString(mousestr, mouseX	, mouseY);
	}
	public static void main(String[] args) {
		AwtTest d=new AwtTest();
		d.setTitle("AWTС����");
		d.setSize(500,300);
		d.setVisible(true);
	}
}
class MyMouseAdapter extends MouseAdapter{
	AwtTest demo;
	public MyMouseAdapter(AwtTest demo) {
		this.demo=demo;
	}
	public void mousePressed(MouseEvent me){
		demo.mouseX=me.getX();
		demo.mouseY=me.getY();
		demo.mousestr="��ǰ����: "+demo.mouseX+","+demo.mouseY;
		demo.repaint();
	}
}
class MyKeyAdapter extends KeyAdapter{
	AwtTest demo;
	public MyKeyAdapter(AwtTest demo){
		this.demo=demo;
	}
	public void KeyTyped(KeyEvent e){
		demo.keystr+=e.getKeyChar();
		demo.repaint();
	}
}
class 	MyWindowAdapter extends WindowAdapter{
	public void WindowClosing(WindowEvent we) {
		System.exit(0);
	}
}