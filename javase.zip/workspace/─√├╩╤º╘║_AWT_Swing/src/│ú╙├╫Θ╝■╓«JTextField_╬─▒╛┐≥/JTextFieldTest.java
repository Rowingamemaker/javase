package �������֮JTextField_�ı���;
/**
 * 
 */
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JTextFieldTest extends JFrame{
	public static void main(String[] args) {
		new JTextFieldTest();
	}
	///���
	JPanel jp=new JPanel();
	//�ı���
	JTextField jtf=new JTextField("�ı���");
	public JTextFieldTest() {
		// TODO Auto-generated constructor stub
		jtf.addActionListener(new MyActionListener());
		///�����ı����С
		jtf.setBounds(10,10,200,25);
		jp.add(new Label("�������"));
		jp.add(jtf);
		this.add(jp);
		this.setSize(500,400);
		this.setTitle("JTextField");
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
			
		});

	}
	///�¼�������
	class MyActionListener  implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			/////getText():����ı����ڵ�����
			JTextFieldTest.this.setTitle(jtf.getText());
			jtf.setText("");
			///ˢ��
			JTextFieldTest.this.repaint();
			
		}
		
	}

}
