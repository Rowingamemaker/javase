package �¼�������;

import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class MyFrame extends JFrame{	
	public MyFrame() {
		// TODO Auto-generated constructor stub
		this.setTitle("���ڵ��¼�������");
		this.setSize(500,400);
		this.setVisible(true);	
		///�����¼�������
		this.addWindowListener(new MyWindowListener());
		this.addWindowFocusListener(new MyWindowListener());
	}
	public static void main(String[] args) {
		new MyFrame();
	}
}
//�¼�������
class MyWindowListener implements WindowListener,WindowFocusListener{

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("���ڴ�");
	}

	@Override
	public void windowClosing(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("���ڹر�");
		System.exit(0);
	}

	@Override
	public void windowClosed(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("��С��");
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("���");
	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowGainedFocus(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("���ڻ�ý���");
	}

	@Override
	public void windowLostFocus(WindowEvent e) {
		// TODO Auto-generated method stub
		System.out.println("����ʧȥ����");
	}
	
}

