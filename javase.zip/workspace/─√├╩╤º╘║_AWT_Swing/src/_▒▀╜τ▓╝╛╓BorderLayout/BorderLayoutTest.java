package _�߽粼��BorderLayout;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * 
 * @author Rowin
 * 2017-3-27
 *
 */
public class BorderLayoutTest extends JFrame{
	public static void main(String[] args) {
		new BorderLayoutTest();
	}
	public BorderLayoutTest() {
		// TODO Auto-generated constructor stub
		JPanel jp=new JPanel();
		JPanel jp1=new JPanel();
		//���������ü��
//		BorderLayout bl=new BorderLayout();
		BorderLayout bl=new BorderLayout(10,10);

		jp.setLayout(bl);
		jp.add(jp1);
		///���һ��������Ҫ�������,��Ҫ�ڸ�����Ÿ�JPanel
		jp1.add(BorderLayout.NORTH, new JButton("North2"));	
		jp1.add(BorderLayout.NORTH, new JButton("North3"));
		
		jp.add(BorderLayout.SOUTH, new JButton("south"));
		
		jp.add(BorderLayout.WEST, new JButton("WEST"));
		
		jp.add(BorderLayout.EAST, new JButton("EAST"));
		
		this.add(jp);
		this.setTitle("�߽粼��");
		this.setSize(500,400);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});

		
	}
}
