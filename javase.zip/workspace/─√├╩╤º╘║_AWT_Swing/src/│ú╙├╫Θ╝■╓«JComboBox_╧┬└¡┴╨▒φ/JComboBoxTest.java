package �������֮JComboBox_�����б�;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JComboBoxTest extends JFrame implements ItemListener{
	public static void main(String[] args) {
		new JComboBoxTest();
	}
	JPanel jp=new JPanel();
	JComboBox jcb=new JComboBox();
	JLabel jl=new JLabel();
	public JComboBoxTest(){
		//�������б�����Ԫ��
		jcb.addItem("c++");
		jcb.addItem("php");
		jcb.addItem("java");
		//�����¼�������
		jcb.addItemListener(this);
		jp.add(jcb);
		jp.add(jl);
		this.add(jp);
		this.setTitle("JComboBox�ķ���");
		this.setSize(400,400);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
	@Override
	////�¼�������
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		jl.setText((String)e.getItem());
	}
}
