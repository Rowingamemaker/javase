package �������֮JTabbedPane_���ѡ�;

import java.awt.Button;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

/**
 * JTabbedPaneֱ�Ӽ̳�JFrame�ͺ���,����Ҫ������
 * @author Rowin
 * 2017-3-27
 *
 */
public class JTabbedPaneTest {
	public static void main(String[] args) {
		new MyJTabbedPane();
	}

}
class MyJTabbedPane extends JFrame{
	JPanel jp=new JPanel();
	JTabbedPane jtp=new JTabbedPane();
	public MyJTabbedPane(){
		///��ťѡ��
		JPanel buttonjp=new JPanel();
		buttonjp.add(new Button("��ť1"));
		buttonjp.add(new Button("��ť2"));
		buttonjp.add(new Button("��ť3"));
		///��ǩѡ��
		JPanel Lablejl=new JPanel();
		Lablejl.add(new JLabel("��ǩһ"));
		Lablejl.add(new JLabel("��ǩ��"));
		Lablejl.add(new JLabel("��ǩ��"));
		
		jtp.add("JButton",buttonjp);
		jtp.add("JLabel",Lablejl);
		jtp.add("more",null);
		
		jp.add(jtp);

		this.add(jp);
		this.setSize(500,500);
		this.setTitle("JTabbedPane��ʹ��");
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		this.setVisible(true);
	}
	
}
