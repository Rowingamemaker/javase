package �������֮JButter_��ť;
/**
 * һ��������ע��������ť
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JButterTest2 {
	public static void main(String[] args) {
		new MyJFrame();
	}
}
class MyJFrame extends JFrame{
	
	JPanel jf=new JPanel();
	JButton jb1=new JButton("��ť1");
	JButton jb2=new JButton("��ť2");
	JLabel jl=new JLabel("");
	public MyJFrame() {
		// TODO Auto-generated constructor stub
		///��������ťע����ͬ�ļ�����
		MyActionListener ma=new MyActionListener();
		jb1.addActionListener(ma);
		jb2.addActionListener(ma);
		//////////////////////////////////
		jf.add(jb1);
		jf.add(jb2);
		jf.add(jl);
		this.add(jf);
		this.setSize(500,400);
		this.addWindowListener(new WindowAdapter() {
			public void WindowsClosing(WindowEvent e){
				System.exit(0);
			}
		});
		this.setVisible(true);
		
	}
	////
	class MyActionListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if (e.getSource()==jb1) {
				jl.setText("��ť1������");
			}else {
				jl.setText("��ť2������");
			}
		}
		
	}
}
