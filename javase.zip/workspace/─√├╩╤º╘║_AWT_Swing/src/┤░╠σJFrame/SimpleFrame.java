package ����JFrame;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class SimpleFrame extends JFrame {
	public SimpleFrame(){
		//���ô����С
		this.setSize(500,400);
		//��ʾ����
		this.setVisible(true);
		//�رմ���
		this.addWindowListener(new WindowAdapter() {
			public void WindowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
	public static void main(String[] args) {
		new SimpleFrame();
	}
	

}
