package �������֮JRadioButton_��ѡ��;

import java.awt.Frame;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class JRadioButtonTest  extends Frame implements ActionListener{
	public static void main(String[] args) {
		new JRadioButtonTest();
	}
	JPanel jp=new JPanel();
	JRadioButton jrb1=new JRadioButton("php");
	JRadioButton jrb2=new JRadioButton("java");
	JRadioButton jrb3=new JRadioButton("c++");
	JLabel jl=new JLabel();

	public JRadioButtonTest(){
		jrb1.addActionListener(this);
		jrb2.addActionListener(this);
		jrb3.addActionListener(this);
		ButtonGroup bg=new ButtonGroup();
		bg.add(jrb1);
		bg.add(jrb2);
		bg.add(jrb3);
		jp.add(new Label("ѡ������"));
		jp.add(jrb1);
		jp.add(jrb2);
		jp.add(jrb3);
		jp.add(jl);
		this.add(jp);
		this.setSize(400,400);
		this.setVisible(true);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		jl.setText(e.getActionCommand());
	}
	

}
