package �¼�������;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.WindowListener;

import javax.swing.JFrame;

public class MyFrame extends JFrame{	
	public MyFrame() {
		// TODO Auto-generated constructor stub
		this.setTitle("���ڵ��¼�������");
		this.setSize(500,400);
		this.setVisible(true);	
		this.addWindowListener(new MyWindowListener());
	}
	public static void main(String[] args) {
		new MyFrame();
	}
}
//�¼�������
class MyWindowListener extends WindowAdapter{
	@Override
	public void windowClosing(WindowEvent e) {
		System.out.println("�رմ���");
		System.exit(0);
	}
	
	@Override
    public void windowOpened(WindowEvent e) {
    	System.out.println("���ڴ�");
    }

}