package Rowin;

import java.util.Random;
import java.util.Scanner;


/**O  79
 * X  88
 * @author Rowin
 * 2017-3-10
 *������ֵ:int[] boardnumber////�����ж������ϸ�λ����û������
 *����ͼ��:char [] symbol
 *
 */
public class Game implements GameInterface{
	static char symbol[]=new char[9];
	static int boardnumber[]=new int [9];
	static int computerplay[]=new int[9];

	public static void main(String[] args) {
		Game game=new Game();
		game.InitGame(boardnumber);
		boolean flag=true,firstcomputerplay=true;
		int userflag=0;
		int computerflag=0;
		///////////////////////////////////////////////////
		while (flag) {
			game.UserPlay(boardnumber,symbol);
			game.PrintSymbol(symbol);
			flag=game.tell(symbol);
			if (flag==true) {
				if (firstcomputerplay==true) {
					game.ComputerPlay(boardnumber,symbol);
					firstcomputerplay=false;
				}else {
					boardnumber=game.ComputerAssist(boardnumber, symbol);
				}

				game.PrintSymbol(symbol);
				flag=game.tell(symbol);
			}
		}
		///////////////////////////////////////////////////
		for (int i = 0; i < symbol.length; i++) {
			if (symbol[i]=='O') {
				userflag++;
			}else if (symbol[i]=='X') {
				computerflag++;
			}
		}
		System.out.println("\n"+"\n");
		System.out.println("*********");
		if (userflag==3) {
			System.out.println("**���ʤ��**");
		}else if (computerflag==3) {
			System.out.println("**���Ի�ʤ**");
		}else {
			System.out.println("**����ƽ��**");
		}	
		System.out.println("*********");
	}
	///��ʽ������ͼ��
	public void InitBoard(char[] symbol){
		System.out.println("|"+symbol[0]+" |"+ symbol[1] +" |"+symbol[2]+" |");
		System.out.println("һһһһһһһ");
		System.out.println("|"+symbol[3]+" |"+ symbol[4] +" |"+symbol[5]+" |");
		System.out.println("һһһһһһһ");
		System.out.println("|"+symbol[6]+" |"+ symbol[7] +" |"+symbol[8]+" |");
		
	}
	
	///��ʼ��������ֵ
	public	void InitGame(int[] boardnumber){
		for (int i = 0; i <9; i++) {
			boardnumber[i]=0;
		}
	
		}

	@Override
	public void PointOutUser() {
		// TODO Auto-generated method stub
		System.out.println("������������������һ��ʱ,���ʤ����");
	}

	@Override
	public  int[]  UserPlay(int[] boardnumber,char []symbol) {
		// TODO Auto-generated method stub
		int flag;
		while (true) {
			System.out.print("��ҳ���: ");
			Scanner sc=new Scanner(System.in);
			flag=sc.nextInt();
			if (flag!=boardnumber[flag-1]) {
				boardnumber[flag-1]=flag;
				symbol[flag-1]='O';
				////test
//				System.out.println(symbol[flag-1]);
				return boardnumber;
			}else if (flag>=9) {
				System.out.println("������1~10������!");
			}else {
				System.out.println("����λ�Ѿ����˳���!");
			}
			
		}

	}
	@Override
	//1.����ʹ�Լ�����λ�������
	//2.���Է�user����λ
	public int[]  ComputerPlay(int[] boardnumber,char []symbol) {
		// TODO Auto-generated method stub
		int flag;
		System.out.print("���Գ���:  ");
		while (true) {
			int flag1=new Random().nextInt();
		
//			if (flag==1) {
//				int inflag;
//				inflag=new Random().nextInt(3);
//				if (boardnumber[flag]!=(flag+1)) {
//					boardnumber[flag]=flag+1;
//					symbol[flag]='X';
//					break;
//				}else if (boardnumber[flag+2]!=(flag+3)) {
//					boardnumber[flag+2]=flag+3;
//					symbol[flag+2]='X';
//					break;
//				}else if (boardnumber[flag+3]!=(flag+4)) {
//					boardnumber[flag+3]=flag+4;
//					symbol[flag+3]='X';
//					break;
//				}
//			}
			if (flag1!=boardnumber[flag1-1]) {
				System.out.println(flag1);
				boardnumber[flag1-1]=flag1;
				symbol[flag1-1]='X';
				////test
				System.out.println(symbol[flag1-1]);
				return boardnumber;
			}
		}
	}

	@Override
	//��ӡͼ��//me 
	public void PrintSymbol(char[] symbol) {
		// TODO Auto-generated method stub
		System.out.println("|"+symbol[0]+" |"+ symbol[1] +" |"+symbol[2]+" |");
		System.out.println("һһһһһһһ");
		System.out.println("|"+symbol[3]+" |"+ symbol[4] +" |"+symbol[5]+" |");
		System.out.println("һһһһһһһ");
		System.out.println("|"+symbol[6]+" |"+ symbol[7] +" |"+symbol[8]+" |");
	}

	@Override
	public boolean tell(char[] symbol) {
		// TODO Auto-generated method stub
		if (symbol[1]==symbol[2]&&symbol[1]==symbol[0]&&symbol[0]==symbol[2]&&(symbol[1]=='O'||symbol[1]=='X')) {
			return false;
		}else if (symbol[1]==symbol[4]&&symbol[1]==symbol[7]&&symbol[4]==symbol[7]&&(symbol[7]=='O'||symbol[7]=='X')) {
			return false;
		}else if (symbol[2]==symbol[5]&&symbol[2]==symbol[8]&&symbol[5]==symbol[8]&&(symbol[8]=='O'||symbol[8]=='X')) {
			return false;
		}else if (symbol[0]==symbol[3]&&symbol[0]==symbol[6]&&symbol[3]==symbol[6]&&(symbol[6]=='O'||symbol[6]=='X')) {
			return false;
		}else if (symbol[0]==symbol[4]&&symbol[0]==symbol[8]&&symbol[4]==symbol[8]&&(symbol[8]=='O'||symbol[8]=='X')) {
			return false;
		}else if (symbol[3]==symbol[4]&&symbol[3]==symbol[5]&&symbol[4]==symbol[5]&&(symbol[5]=='O'||symbol[5]=='X')) {
			return false;
		}else if (symbol[2]==symbol[4]&&symbol[2]==symbol[6]&&symbol[4]==symbol[6]&&(symbol[6]=='O'||symbol[6]=='X')) {
			return false;
		}else if (symbol[6]==symbol[7]&&symbol[6]==symbol[8]&&symbol[7]==symbol[8]&&(symbol[8]=='O'||symbol[8]=='X')) {
			return false;
		}else {
			return true;
			
		}

	}
	////���Ը����ж�
//	1 2 3 
//
//	4 5 6
//
//	7 8 9

	public	int[] ComputerAssist(int[] boardnumber,char []symbol){
		//1.����ʹ�Լ�����λ�������
		//2.���Է�user����λ
		System.out.println("���Գ���:  ");
		for (int i = 0; i < 9; i++) {
			if (symbol[i]=='X') {
//				if (i==0||i==3) {
//					if (boardnumber[i+1]!=(i+2)) {
//						boardnumber[i+1]=(i+2);
//						symbol[i+1]='X';
//						break;
//					}else if (boardnumber[i+3]!=(i+4)) {
//						boardnumber[i+3]=(i+4);
//						symbol[i+3]='X';
//						break;
//					}else if(boardnumber[i+4]!=(i+5)) {
//						boardnumber[i+4]=(i+5);
//						symbol[i+4]='X';
//						break;
//					}
//				}
				if (i==0) {
					if (boardnumber[1]!=2) {
						boardnumber[1]=2;
						symbol[1]='X';
						break;
					}else if (boardnumber[3]!=4) {
						boardnumber[3]=4;
						symbol[3]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}
				}
				if (i==1) {
					if (boardnumber[0]!=1) {
						boardnumber[0]=1;
						symbol[0]='X';
						break;
					}else if (boardnumber[2]!=3) {
						boardnumber[2]=3;
						symbol[3]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}
				}
				if (i==2) {
					if (boardnumber[1]!=2) {
						boardnumber[1]=2;
						symbol[1]='X';
						break;
					}else if (boardnumber[5]!=6) {
						boardnumber[5]=6;
						symbol[5]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}
				}
				if (i==3) {
					if (boardnumber[0]!=1) {
						boardnumber[0]=1;
						symbol[0]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}else if (boardnumber[6]!=7) {
						boardnumber[6]=7;
						symbol[6]='X';
						break;
					}
				}
				if (i==4) {
					for (int j = 0; j < 9; j++) {
						if (j!=4) {
							if (boardnumber[j]!=(j+1)) {
								boardnumber[j]=(j+1);
								symbol[j]='X';
								break;
							}
						}
					}
				}
				if (i==5) {
					if (boardnumber[2]!=3) {
						boardnumber[2]=3;
						symbol[2]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}else if (boardnumber[8]!=9) {
						boardnumber[8]=9;
						symbol[8]='X';
						break;
					}
				}
				if (i==6) {
					if (boardnumber[7]!=8) {
						boardnumber[7]=8;
						symbol[7]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}else if (boardnumber[3]!=4) {
						boardnumber[3]=4;
						symbol[3]='X';
						break;
					}
				}
				if (i==7) {
					if (boardnumber[8]!=9) {
						boardnumber[8]=9;
						symbol[8]='X';
						break;
					}else if (boardnumber[6]!=7) {
						boardnumber[6]=7;
						symbol[6]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}
				}
				if (i==8) {
					if (boardnumber[7]!=8) {
						boardnumber[7]=8;
						symbol[7]='X';
						break;
					}else if (boardnumber[4]!=5) {
						boardnumber[4]=5;
						symbol[4]='X';
						break;
					}else if (boardnumber[5]!=6) {
						boardnumber[5]=6;
						symbol[5]='X';
						break;
					}
				}
			}
		}
		//2.���Է�user����λ
		return boardnumber;
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	




