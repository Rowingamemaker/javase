package Rowin;

import java.util.Random;

import javax.rmi.CORBA.Tie;

//int[][] board=new int[3][3];
//int flag=1;
//for (int i = 0; i < 3; i++) {
//	for (int j = 0; j < 3; j++) {
//		board[i][j]=flag;
//		flag++;	
//		System.out.print(board[i][j]);
//		}
//	
//}
//char [] symbol=new char[9];
//symbol[0]='O';
//System.out.println("|"+symbol[0]+" |"+ symbol[0] +" |"+symbol[0]+" |");
//System.out.println("һһһһһһһ");
//System.out.println("|"+symbol[0]+" |"+ symbol[0] +" |"+symbol[0]+" |");
//System.out.println("һһһһһһһ");
//System.out.println("|"+symbol[0]+" |"+ symbol[0] +" |"+symbol[0]+" |");
public class Test extends Game{
	public static void main(String[] args) {

		int inflag;
		inflag=new Random().nextInt(3);

		System.out.println(inflag);
		
		
		
		}
}
