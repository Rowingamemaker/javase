package Rowin;

public class MyException1 {
	public static void main(String[] args) {
		try {
			ageLevel(1000);
		} catch (IllegalAgeException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	static String ageLevel(int age) throws IllegalAgeException {
		if (age >= 10 && age <= 18) {
			return "����";
		} else if (age > 18 && age <= 22) {
			return "����";
		} else if (age > 22 && age <= 50) {
			return "����";
		} else if (age > 50 && age <= 80) {
			return "����";
		} else {
			throw new IllegalAgeException("�Ƿ�������!!!!");
		}

	}

}

class IllegalAgeException extends Exception {
	public IllegalAgeException(String msg) {
		super(msg);
	}

}
