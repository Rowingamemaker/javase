package �������������;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 * �������������д��һ��
 * @author Rowin
 * 2017-3-19
 *
 */
public class BufferedTest {
	public static void main(String[] args) {
		////����BufferedInputStream������
		FileInputStream fis=null;
		BufferedInputStream bis=null;
		////����BufferedOutputStream�����
		FileOutputStream fos=null;
		BufferedOutputStream bos=null;
		
		try {
			fis=new FileInputStream("C:\\Users\\Rowin\\Desktop\\in.txt");
			bis=new BufferedInputStream(fis);
			fos=new FileOutputStream("C:\\Users\\Rowin\\Desktop\\out.txt");
			bos=new BufferedOutputStream(fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int c=0;
		try {
			c=bis.read();
			while (c!=-1) {
				System.out.print((char)c);
				bos.write(c);
				c=bis.read();
			}
			bos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (fis!=null){
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else if (bis!=null) {
				try {
					bis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else if (fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else if (bos!=null) {
				try {
					bos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}

		
		
	}

}
