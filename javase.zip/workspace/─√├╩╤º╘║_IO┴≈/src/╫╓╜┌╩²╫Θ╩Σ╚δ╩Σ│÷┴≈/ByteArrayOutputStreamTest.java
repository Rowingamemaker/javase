package �ֽ��������������;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ByteArrayOutputStreamTest {
	public static void main(String[] args) {
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		String s="Hello Rowin,I LOVE U";
		byte[]  b1=s.getBytes();
		
		try {
			baos.write(b1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(baos);
		
		
	}

}
