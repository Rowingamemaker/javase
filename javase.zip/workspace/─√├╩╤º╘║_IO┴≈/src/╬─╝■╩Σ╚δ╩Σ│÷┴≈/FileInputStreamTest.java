package �ļ����������;
/**
 * InPutStream�������ֽڵ��������ĸ���  ////������: ���ļ�
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileInputStreamTest {
	public static void main(String[] args) {
		FileInputStream f=null;
		int i=0;
		try {
			f=new FileInputStream("C:\\Users\\Rowin\\Desktop\\C++_and_Qt\\C��ҵ.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			i=f.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		while(i!=-1) {
			System.out.print((char)i);
			try {
				i=f.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

}
