package ��д�ļ���;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * InputStreamReader��FileReader��Ա�,FileReader�Ĳ������,����FileReader�Ǽ̳���InputStreamReader
 * @author Rowin
 * 2017-3-19
 *
 */
public class FileReaderText {
	public static void main(String[] args) {
		FileReader fr=null;
		
		try {
			fr=new FileReader("C:\\Users\\Rowin\\Desktop\\in.txt");
			int c;
			c=fr.read();
			while (c!=-1) {
				System.out.print((char)c);
				c=fr.read();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (fr!=null) {
				try {
					fr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

}
