package ��д�ļ���;

import java.io.FileWriter;
import java.io.IOException;

/**
 * 
 * @author Rowin
 * 2017-3-19
 *
 */
public class FileWriterTest {
	public static void main(String[] args) {
		FileWriter fw=null;
		
		try {
			fw=new FileWriter("C:\\Users\\Rowin\\Desktop\\out.txt");
			String  s="�������� 39644245464520..";
			for (int i = 0; i < s.length(); i++) {
				fw.write(s.charAt(i));
			}
			fw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
