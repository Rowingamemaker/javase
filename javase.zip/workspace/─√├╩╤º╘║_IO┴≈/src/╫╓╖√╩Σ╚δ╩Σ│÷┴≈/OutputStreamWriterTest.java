package �ַ����������;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * OutputStreamWriter�Ǵ��ַ����ֽ�
 * ��close��ʱ��,��Ĭ��flush           flush��ˢ��,��Ȼ��д����ȥ 
 * @author Rowin
 * 2017-3-19
 *
 */
public class OutputStreamWriterTest {
	public static void main(String[] args) {
		FileOutputStream fos=null;
		OutputStreamWriter osw=null;
		
		try {
			fos=new FileOutputStream("C:\\Users\\Rowin\\Desktop\\in.txt");
			osw=new OutputStreamWriter(fos);
			String s="�ܸ��˼������,Nice to meet you";
			for (int i = 0; i < s.length(); i++) {
				///string��charAt():����ָ���������� char ֵ
				osw.write(s.charAt(i));
				
			}
			osw.flush();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (fos!=null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (osw!=null) {
				try {
					osw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}

		
		
	}

}
