package ��ʶIO��;

import java.io.File;
import java.util.Iterator;

public class FileTest {
	public static void main(String[] args) {
		File f1=new File("C:\\Users\\Rowin\\Desktop\\C++_and_Qt\\ʾ������     QT");
		File[] files=f1.listFiles();
		f1.exists();
		f1.mkdir();
		f1.mkdirs();
		for (File file : files) {
			System.out.println(file.getName());
			System.out.println(file.getPath());
			System.out.println(file.getTotalSpace());
			
		}
	}

}
