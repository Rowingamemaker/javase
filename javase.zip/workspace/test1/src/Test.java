/*
 * һ������
 */

public class Test {

		private float L;
		private float W;
		
		
		public float getL() {
			return L;
		}
		public float getW() {
			return W;
		}
		
		public void setL(float l) {
			L = l;
		}
		public void setW(float w) {
			W = w;
		}
		public float getC() {
			return (L+W)*2;
		}
		public float getS() {
			return L*W;
		}
		@Override
		public String toString() {
			return "Test [L=" + L + ", W=" + W + "]"+"���"+getS()+"�ܳ�"+getC();
		}

		
		
		

	}