
public class Test1 {

	public static void main(String[] args) {
		
		Test n1=new Test();
		n1.setL(10);
		n1.setW(5);
		String result=n1.toString();
		System.out.println(result);
	}
}
